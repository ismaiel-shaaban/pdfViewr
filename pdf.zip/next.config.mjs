/** @type {import('next').NextConfig} */
const nextConfig = {
    basePath: '',
};

export default nextConfig;
